// railwayChat.js

const routes = {
  "chennai to madurai": "Pandian Express (12637) - 21:40 → 05:40",
  "chennai to coimbatore": "Covai Express (12677) - 05:00 → 09:30",
  "chennai to trichy": "Cholan Express (16170) - 19:20 → 04:30",
  "chennai to bangalore": "Bangalore Express (12673) - 21:20 → 05:50",
  "madurai to coimbatore": "Vaigai Express (12635) - 13:20 → 21:25",
  "madurai to trichy": "Rockfort Express (12671) - 08:40 → 09:50",
  "coimbatore to bangalore": "Coimbatore Express (12643) - 06:00 → 10:30",
  "trichy to bangalore": "Tiruchendur Express (12679) - 16:20 → 05:00",
  "chennai to salem": "Salem Express (12681) - 12:15 → 17:30",
  "chennai to pondicherry": "Pondy Express (12605) - 06:30 → 09:45"
};

module.exports = routes;
